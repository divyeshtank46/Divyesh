
// // Swap Numbers

// let a=10;
// let b=20;

// a=a^b;
// b=b^a;
// a=a^b;
// console.log("Value After Swap")
// console.log("a:",a);
// console.log("b:",b);


// // Find Area Of RectAngle

// let length=50;
// let width=100;

// let area=length * width ;

// console.log("Area Of Rectangle is :" ,area);

// // Simple Intrest
// let price =10000;
// let time =8;
// let rate=2;

// let Intrest = price * time *rate/100;
// console.log(Intrest);

// // Odd Even Program
// let number =19;
// // even=true odd = false 


// let output= number%2==0 ? "even" : "odd";
// console.log(output);


// // Concatenate 
// let firstName="divyesh";
// let lasName="tank";
// let fullName=firstName+" " + lasName ;
// console.log(fullName);


// // Deegree to Celsios

// let Celsios=15;

// let Fahrenheit=(Celsios * 9/5)+32;
// console.log("value in fahrenheit: "Fahrenheit);
